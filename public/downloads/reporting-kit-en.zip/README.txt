Iter Advisors teaching kit, 2 October 2026. All data is fictitious.
UTF-8 CSV, semicolon delimiter. Expenses are positive. Simplified balance = revenue - expenses, not accounting EBITDA.
Dictionary: id = unique identifier; period = month; entity = company; unit = thousands of euros (kEUR); category = Revenue or Expenses; item = detail; budget and actual = amounts.
The duplicate file repeats R01. Do not validate aggregations before resolving the duplicate. Removing the exact repetition restores the answer key.
Variance = actual - budget. Relative variance = variance / budget; not calculable if budget is zero. Expected relative variances: revenue -10%, expenses +3.33%, simplified balance -50%.
No cause is supplied. Any causal explanation must remain a hypothesis.
Read the full pilot protocol: https://www.iteradvisors.com/en/resources/ai-finance/90-day-roadmap
